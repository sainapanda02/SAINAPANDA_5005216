package FinancialForecasting;

public class Recursive_FinancialForecasting {
    
    // Recursive method to calculate future value
    public static double predictFutureValue(double initialValue, double growthRate, int years) {
        // Base case: if years is 0, the future value is the initial value
        if (years == 0) {
            return initialValue;
        }

        // Recursive case: calculate the future value for (years - 1) and apply the growth rate
        double previousValue = predictFutureValue(initialValue, growthRate, years - 1);
        return previousValue * (1 + growthRate);
    }

    public static void main(String[] args) {
        double initialValue = 1000.0; // Initial value
        double growthRate = 0.05; // Annual growth rate (5%)
        int years = 10; // Number of years into the future

        double futureValue = predictFutureValue(initialValue, growthRate, years);
        System.out.printf("Future value after %d years: %.2f%n", years, futureValue);
    }
}

