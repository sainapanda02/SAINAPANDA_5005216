package EmployeeManagementSystem;
import java.util.Scanner;

public class employeemanagementsystem {
    private Employee[] employees;
    private int size;

    public employeemanagementsystem(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }

    public void addEmployee(Employee employee) {
        if (size < employees.length) {
            employees[size] = employee;
            size++;
        } else {
            System.out.println("Array is full, cannot add more employees.");
        }
    }

    public Employee searchEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                return employees[i];
            }
        }
        return null;
    }

    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    public void deleteEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                for (int j = i; j < size - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[size - 1] = null;
                size--;
                return;
            }
        }
        System.out.println("Employee not found.");
    }

    public static void main(String[] args) {
        employeemanagementsystem ems = new employeemanagementsystem(5);
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("\nChoose an operation:");
            System.out.println("1. Add Employee");
            System.out.println("2. Search Employee");
            System.out.println("3. Traverse Employees");
            System.out.println("4. Delete Employee");
            System.out.println("5. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    System.out.println("Enter employee ID:");
                    String id = scanner.nextLine();
                    System.out.println("Enter employee name:");
                    String name = scanner.nextLine();
                    System.out.println("Enter employee position:");
                    String position = scanner.nextLine();
                    System.out.println("Enter employee salary:");
                    double salary = scanner.nextDouble();

                    Employee newEmployee = new Employee(id, name, position, salary);
                    ems.addEmployee(newEmployee);
                    System.out.println("Employee added.");
                    break;

                case 2:
                    System.out.println("Enter employee ID to search:");
                    String searchId = scanner.nextLine();
                    Employee foundEmployee = ems.searchEmployee(searchId);
                    if (foundEmployee != null) {
                        System.out.println("Employee found: " + foundEmployee);
                    } else {
                        System.out.println("Employee not found.");
                    }
                    break;

                case 3:
                    System.out.println("Traversing all employees:");
                    ems.traverseEmployees();
                    break;

                case 4:
                    System.out.println("Enter employee ID to delete:");
                    String deleteId = scanner.nextLine();
                    ems.deleteEmployee(deleteId);
                    System.out.println("Employee deleted if existed.");
                    break;

                case 5:
                    exit = true;
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }

        scanner.close();
    }
}
