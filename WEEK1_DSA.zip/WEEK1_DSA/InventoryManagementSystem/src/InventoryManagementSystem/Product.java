package InventoryManagementSystem;

public class Product {
    private int productID;
    private String productName;
    private int quantity;
    private double price;

    public Product(int productID, String productName, int quantity, double price) {
        this.productID = productID;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }

    public int getProductId() {
        return productID;
    }

    public String getProductName() {
        return productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    public String toString() {
        return "Product{id=" + productID + ", name='" + productName + "', quantity=" + quantity + ", price=" + price + "}";
    }

}

