package strategypatternexample;

public class StrategyPatternExample {
    public static void main(String[] args) {
        PaymentContext context = new PaymentContext();

        // Pay using Credit Card
        context.setPaymentStrategy(new CreditCardPayment("1234-5678-9012-3456", "John Doe", "123", "12/25"));
        context.executePayment(100.0);

        // Pay using PayPal
        context.setPaymentStrategy(new PayPalPayment("john.doe@example.com", "password123"));
        context.executePayment(200.0);
    }
}
