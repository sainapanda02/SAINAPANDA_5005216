package decoratorpatternexample;

public class DecoratorPatternExample {
    public static void main(String[] args) {
        // Create an email notifier
        Notifier emailNotifier = new EmailNotifier();

        // Decorate the email notifier with SMS functionality
        Notifier emailAndSMSNotifier = new SMSNotifierDecorator(emailNotifier);

        // Decorate the email and SMS notifier with Slack functionality
        Notifier emailAndSMSAndSlackNotifier = new SlackNotifierDecorator(emailAndSMSNotifier);

        // Send notification via Email, SMS, and Slack
        emailAndSMSAndSlackNotifier.send("Hello, this is a test notification!");
    }
}
