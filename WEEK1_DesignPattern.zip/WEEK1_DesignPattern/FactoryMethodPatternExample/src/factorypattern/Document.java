package factorypattern;

public interface Document {
    void open();
}

